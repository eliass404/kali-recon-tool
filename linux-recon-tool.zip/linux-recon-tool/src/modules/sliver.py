def run_sliver():
    """Run Sliver C2 Framework."""
    import subprocess
    print("Starting Sliver Framework...")
    try:
        subprocess.run(["sliver"], check=True)
    except FileNotFoundError:
        print("Error: Sliver is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Sliver: {e}")