def run_crackmapexec():
    """Run CrackMapExec."""
    import subprocess
    print("Starting CrackMapExec...")
    try:
        subprocess.run(["crackmapexec"], check=True)
    except FileNotFoundError:
        print("Error: CrackMapExec is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running CrackMapExec: {e}")