def run_routersploit():
    """Run Routersploit Framework."""
    import subprocess
    print("Starting Routersploit Framework...")
    try:
        subprocess.run(["routersploit"], check=True)
    except FileNotFoundError:
        print("Error: Routersploit is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Routersploit: {e}")