def run_sublist3r(domain):
    import subprocess

    try:
        # Run Sublist3r command
        command = f"sublist3r -d {domain} -o {domain}_subdomains.txt"
        subprocess.run(command, shell=True, check=True)
        print(f"Subdomain enumeration completed. Results saved to {domain}_subdomains.txt")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Sublist3r: {e}")

def main():
    print("Sublist3r Module")
    domain = input("Enter the domain for subdomain enumeration: ")
    run_sublist3r(domain)

if __name__ == "__main__":
    main()