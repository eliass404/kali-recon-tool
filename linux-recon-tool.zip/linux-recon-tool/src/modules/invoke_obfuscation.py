def run_invoke_obfuscation():
    """Run Invoke-Obfuscation."""
    import subprocess
    print("Starting Invoke-Obfuscation...")
    try:
        subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-File", "Invoke-Obfuscation.ps1"], check=True)
    except FileNotFoundError:
        print("Error: Invoke-Obfuscation is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Invoke-Obfuscation: {e}")