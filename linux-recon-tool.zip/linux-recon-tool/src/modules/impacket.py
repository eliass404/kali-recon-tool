def run_impacket():
    """Run Impacket tools."""
    import subprocess
    print("Select an Impacket tool to run:")
    print("1. smbclient.py")
    print("2. psexec.py")
    print("3. Exit to Main Menu")
    choice = input("Enter your choice (1-3): ")

    if choice == '1':
        try:
            subprocess.run(["smbclient.py"], check=True)
        except FileNotFoundError:
            print("Error: smbclient.py is not installed or not in the system PATH.")
        except subprocess.CalledProcessError as e:
            print(f"An error occurred while running smbclient.py: {e}")
    elif choice == '2':
        try:
            subprocess.run(["psexec.py"], check=True)
        except FileNotFoundError:
            print("Error: psexec.py is not installed or not in the system PATH.")
        except subprocess.CalledProcessError as e:
            print(f"An error occurred while running psexec.py: {e}")
    elif choice == '3':
        print("Returning to the main menu...")
    else:
        print("Invalid choice. Returning to the main menu.")