def run_faraday():
    """Run Faraday."""
    import subprocess
    print("Starting Faraday...")
    try:
        subprocess.run(["faraday"], check=True)
    except FileNotFoundError:
        print("Error: Faraday is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Faraday: {e}")