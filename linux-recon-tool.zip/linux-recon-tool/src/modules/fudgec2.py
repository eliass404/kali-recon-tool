def run_fudgec2():
    """Run FudgeC2."""
    import subprocess
    print("Starting FudgeC2...")
    try:
        subprocess.run(["fudgec2"], check=True)
    except FileNotFoundError:
        print("Error: FudgeC2 is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running FudgeC2: {e}")