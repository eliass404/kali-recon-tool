def run_evil_winrm():
    """Run Evil-WinRM."""
    import subprocess
    print("Starting Evil-WinRM...")
    try:
        subprocess.run(["evil-winrm"], check=True)
    except FileNotFoundError:
        print("Error: Evil-WinRM is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Evil-WinRM: {e}")