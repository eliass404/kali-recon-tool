def run_amass(domain):
    import subprocess

    command = ["amass", "enum", "-d", domain]
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        return f"Error running Amass: {e.stderr}"

def domain_enumeration(domain):
    print(f"Starting domain enumeration for: {domain}")
    output = run_amass(domain)
    print(output)