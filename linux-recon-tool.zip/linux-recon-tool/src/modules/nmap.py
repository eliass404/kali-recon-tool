def run_nmap_scan(target, options):
    import subprocess

    command = ['nmap'] + options + [target]
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        return f"Error running Nmap: {e.stderr}"

def scan_ports(target):
    options = ['-p', '1-65535']  # Scan all ports
    return run_nmap_scan(target, options)

def scan_os(target):
    options = ['-O']  # OS detection
    return run_nmap_scan(target, options)

def scan_service(target):
    options = ['-sV']  # Service version detection
    return run_nmap_scan(target, options)

def scan_with_options(target, custom_options):
    return run_nmap_scan(target, custom_options)