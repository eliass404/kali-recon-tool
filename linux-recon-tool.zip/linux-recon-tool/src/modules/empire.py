def run_empire():
    """Run Empire Framework."""
    import subprocess
    print("Starting Empire Framework...")
    try:
        subprocess.run(["empire"], check=True)
    except FileNotFoundError:
        print("Error: Empire is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Empire: {e}")