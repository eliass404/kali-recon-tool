def run_magictree():
    """Run MagicTree."""
    import subprocess
    print("Starting MagicTree...")
    try:
        subprocess.run(["magictree"], check=True)
    except FileNotFoundError:
        print("Error: MagicTree is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running MagicTree: {e}")