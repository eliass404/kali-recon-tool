import os
import subprocess
import sys

# Add modules/ to path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "modules"))

# Import all modules that exist as Python files in modules/
try:
    import amass
except ModuleNotFoundError:
    amass = None
    print("Warning: 'amass' module not found in 'modules/'. Some functionality may be unavailable.")
import nmap, sublist3r, exploitdb
import empire, sliver, pupy, crackmapexec
import evil_winrm, invoke_obfuscation, fudgec2
import magictree, faraday
import impacket  # This should be your own modules/impacket.py
import routersploit as routersploit_module

def run_routersploit():
    routersploit_module.run_routersploit()

def run_metasploit():
    print("Starting Metasploit Framework...")
    try:
        subprocess.run(["msfconsole"], check=True)
    except FileNotFoundError:
        print("Error: Metasploit is not installed or not in the system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running Metasploit: {e}")

def display_banner():
    terminal_width = os.get_terminal_size().columns
    banner = "Programmed by eliass_404"
    print(banner.center(terminal_width))
    print("=" * terminal_width)

def install_and_update():
    print("Installing and updating tools...")
    try:
        subprocess.run(["sudo", "apt", "update"], check=True)
        subprocess.run(["sudo", "apt", "upgrade", "-y"], check=True)
        tools = [
            "recon-ng", "amass", "nmap", "sublist3r", "metasploit-framework",
            "routersploit", "impacket-scripts", "exploitdb"
        ]
        for tool in tools:
            print(f"Installing {tool}...")
            subprocess.run(["sudo", "apt", "install", "-y", tool], check=True)
        print("All tools installed and system updated successfully!")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

def display_menu():
    cyan = "\033[96m"
    yellow = "\033[93m"
    green = "\033[92m"
    reset = "\033[0m"
    print(f"{cyan}{'='*50}")
    print(f"{yellow}{'Linux Recon Tool':^50}")
    print(f"{cyan}{'='*50}{reset}")
    print(f"{green}Reconnaissance & Enumeration:{reset}")
    print(f"  {yellow}1{reset}. Recon-ng")
    print(f"  {yellow}2{reset}. Amass")
    print(f"  {yellow}3{reset}. Nmap")
    print(f"  {yellow}4{reset}. Sublist3r")
    print(f"  {yellow}5{reset}. Metasploit Framework")
    print(f"  {yellow}6{reset}. Routersploit")
    print(f"  {yellow}7{reset}. Impacket")
    print(f"  {yellow}8{reset}. ExploitDB")
    print(f"{green}Post-Exploitation & C2:{reset}")
    print(f"  {yellow}9{reset}. Empire")
    print(f"  {yellow}10{reset}. Sliver")
    print(f"  {yellow}11{reset}. Pupy")
    print(f"  {yellow}12{reset}. CrackMapExec")
    print(f"{green}Persistence, Evasion, & Bypasses:{reset}")
    print(f"  {yellow}13{reset}. Evil-WinRM")
    print(f"  {yellow}14{reset}. Invoke-Obfuscation")
    print(f"  {yellow}15{reset}. FudgeC2")
    print(f"{green}Reporting & Collaboration:{reset}")
    print(f"  {yellow}16{reset}. MagicTree")
    print(f"  {yellow}17{reset}. Faraday")
    print(f"{cyan}{'-'*50}{reset}")
    print(f"  {yellow}18{reset}. Install and Update Tools")
    print(f"  {yellow}19{reset}. Exit")
    print(f"{cyan}{'='*50}{reset}")

def main():
    display_banner()
    while True:
        display_menu()
        choice = input("Enter your choice: ").strip()
        try:
            if choice == '1':
                # Recon-ng: just run the command
                subprocess.run(["recon-ng"])
            elif choice == '2':
                if amass:
                    domain = input("Enter the domain for Amass: ")
                    amass.domain_enumeration(domain)
                else:
                    print("Amass module not found.")
            elif choice == '3':
                target = input("Enter the target for Nmap: ")
                print(nmap.scan_ports(target))
            elif choice == '4':
                domain = input("Enter the domain for Sublist3r: ")
                sublist3r.run_sublist3r(domain)
            elif choice == '5':
                run_metasploit()
            elif choice == '6':
                run_routersploit()
            elif choice == '7':
                impacket.run_impacket()
            elif choice == '8':
                exploitdb.run_exploitdb()
            elif choice == '9':
                empire.run_empire()
            elif choice == '10':
                sliver.run_sliver()
            elif choice == '11':
                pupy.run_pupy()
            elif choice == '12':
                crackmapexec.run_crackmapexec()
            elif choice == '13':
                evil_winrm.run_evil_winrm()
            elif choice == '14':
                invoke_obfuscation.run_invoke_obfuscation()
            elif choice == '15':
                fudgec2.run_fudgec2()
            elif choice == '16':
                magictree.run_magictree()
            elif choice == '17':
                faraday.run_faraday()
            elif choice == '18':
                install_and_update()
            elif choice == '19':
                print("Exiting...")
                break
            else:
                print("Invalid choice. Try again.")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()

