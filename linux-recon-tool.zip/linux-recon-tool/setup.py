from setuptools import setup, find_packages

setup(
    name='linux-recon-tool',
    version='0.1',
    author='Your Name',
    author_email='your.email@example.com',
    description='A tool for reconnaissance and enumeration using various modules.',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        # List your dependencies here
        # e.g., 'requests', 'beautifulsoup4', etc.
    ],
    entry_points={
        'console_scripts': [
            'linux-recon-tool=main:main',  # Adjust this based on your main function location
        ],
    },
)